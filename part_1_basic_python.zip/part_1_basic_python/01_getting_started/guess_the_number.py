#############################
### ch00_guess_the_number ###
#############################

"""
This script plays a game with the user.
The computer chooses a number, and the user tries to guess it
"""

# import necessary module
import random

# The computer "chooses" a number
my_number = random.randint(1, 100)

# The program asks you to play
print "I have chosen a number between 1 and 100. Please try to guess it..."

# The program reads your guess and stores it
user_guess = int(raw_input())

# The game is on...
while my_number != user_guess:
    print "Wrong! ",
    if user_guess > my_number:
        user_guess = int(raw_input("You are too high, please try again..."))
    else:
        user_guess = int(raw_input("You are too low, please try again..."))

print "Finally :-)\nGAME OVER"

