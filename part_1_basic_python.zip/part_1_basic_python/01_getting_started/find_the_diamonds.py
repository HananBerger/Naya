##############################
### ch00_find_the_diamonds ###
##############################

"""
This script lists all the records in a given csv file
which follow a specified rule
"""

# import necessary module
import csv

# Specify file location
file_path = 'C:\\temp\\diamonds.csv'

# Initiate the list of required elements
good_diamonds = []

# Introduce the file to the program
csvfile = open(file_path, 'r')
data = csv.DictReader(csvfile)

# Iterate over rows
for diamond in data:
    if float(diamond['carat']) > 1.1:
        good_diamonds.append(int(diamond['#']))

# Show results
print good_diamonds